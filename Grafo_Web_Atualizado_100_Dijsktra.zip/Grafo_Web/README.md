# Visualizador de Grafos

Página web simples para criar e editar grafos e executar BFS / DFS passo a passo.

## Como usar

1. Abra `index.html` no navegador.
2. Adicione nós usando o campo `Nome do nó`.
3. Adicione arestas selecionando os nós de origem e destino e clicando em `Adicionar aresta`.
4. Selecione o nó inicial e clique em `Executar BFS` ou `Executar DFS`.
5. Use `Anterior` e `Próximo` para avançar pelos passos.
6. Arraste os nós no painel para reorganizar o grafo.
