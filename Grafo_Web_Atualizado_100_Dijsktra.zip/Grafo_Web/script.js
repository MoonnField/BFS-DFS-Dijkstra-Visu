const graphCanvas = document.getElementById('graphCanvas');
const nodeNameInput = document.getElementById('nodeName');
const addNodeButton = document.getElementById('addNode');
const edgeFromSelect = document.getElementById('edgeFrom');
const edgeToSelect = document.getElementById('edgeTo');
const addEdgeButton = document.getElementById('addEdge');
const edgeWeightInput = document.getElementById('edgeWeight');
const graphTypeSelect = document.getElementById('graphType');
const startNodeSelect = document.getElementById('startNode');
const runBFSButton = document.getElementById('runBFS');
const runDFSButton = document.getElementById('runDFS');
const runDijkstraButton = document.getElementById('runDijkstra');
const prevStepButton = document.getElementById('prevStep');
const dijkstraResult = document.getElementById('dijkstraResult');
const dijkstraResultContent = document.getElementById('dijkstraResultContent');
const nextStepButton = document.getElementById('nextStep');
const resetAlgoButton = document.getElementById('resetAlgo');
const clearGraphButton = document.getElementById('clearGraph');
const exportGraphButton = document.getElementById('exportGraph');
const importGraphButton = document.getElementById('importGraph');
const importGraphInput = document.getElementById('importGraphInput');
const output = document.getElementById('output');
const nodeCountLabel = document.getElementById('nodeCount');
const edgeCountLabel = document.getElementById('edgeCount');
const weightedGraphCheckbox = document.getElementById('weightedGraph');
const toggleEditPanelButton = document.getElementById('toggleEditPanel');
const graphInfoButton = document.getElementById('graphInfoButton');
const graphInfoModal = document.getElementById('graphInfoModal');
const graphInfoContent = document.getElementById('graphInfoContent');
const zoomOutButton = document.getElementById('zoomOut');
const zoomInButton = document.getElementById('zoomIn');
const panUpButton = document.getElementById('panUp');
const panLeftButton = document.getElementById('panLeft');
const panRightButton = document.getElementById('panRight');
const panDownButton = document.getElementById('panDown');
const specialGraphTypeSelect = document.getElementById('specialGraphType');
const specialGraphSizeInput = document.getElementById('specialGraphSize');
const generateSpecialGraphButton = document.getElementById('generateSpecialGraph');
const toggleStatusPanelButton = document.getElementById('toggleStatusPanel');
const toggleExecutionPanelButton = document.getElementById('toggleExecutionPanel');
const editPanel = document.querySelector('.edit-panel');
const statusPanel = document.querySelector('.status-panel');
const executionPanel = document.querySelector('.execution-panel');

const svgNS = 'http://www.w3.org/2000/svg';
const svgWidth = 1000;
const svgHeight = 700;

const graph = {
  nodes: [],
  edges: [],
  adjacency: {},
  directed: false,
};

let algorithmState = null;
let currentStepIndex = 0;
let svgElements = { nodes: {}, edges: {} };
let isDragging = false;
let isPanning = false;
let dragTarget = null;
let dragOffset = { x: 0, y: 0 };
let panStart = { x: 0, y: 0 };
let edgeSourceNode = null;
let selectedNode = null;
let selectedEdge = null;
let zoomLevel = 1;
let viewBoxX = 0;
let viewBoxY = 0;
const minZoomLevel = 0.25;
const maxZoomLevel = 3.0;
const zoomStep = 0.18;

function getNewNodePosition() {
  const count = graph.nodes.length;
  const perRow = 5;
  const spacing = 100;
  const margin = 80;
  const row = count % perRow;
  const col = Math.floor(count / perRow);
  return {
    x: margin + row * spacing,
    y: margin + col * spacing,
  };
}

function addNode(name) {
  if (!name || graph.nodes.some((node) => node.name === name)) {
    alert('Nome inválido ou já existente.');
    return;
  }
  const position = getNewNodePosition();
  const node = {
    id: `node-${name}`,
    name,
    x: position.x,
    y: position.y,
  };
  graph.nodes.push(node);
  graph.adjacency[name] = [];
  updateSelectors();
  drawGraph();
}

function addEdge(from, to, weight = edgeWeightInput.value, directed = graph.directed) {
  if (!from || !to || from === to) {
    alert('Escolha dois nós diferentes.');
    return;
  }
  const isDirected = Boolean(directed);
  const hasWeight = weight !== undefined && weight !== null && String(weight).trim() !== '';
  let parsedWeight = undefined;
  if (hasWeight) {
    parsedWeight = Number(weight);
    if (Number.isNaN(parsedWeight)) {
      alert('Informe um peso válido ou deixe em branco para sem peso.');
      return;
    }
  }
  const edgeExists = graph.edges.some((edge) => {
    const edgeDirected = Boolean(edge.directed);
    if (isDirected) {
      return edge.from === from && edge.to === to && edgeDirected === true;
    }
    return (
      edgeDirected === false &&
      ((edge.from === from && edge.to === to) || (edge.from === to && edge.to === from))
    );
  });
  if (edgeExists) {
    alert('Aresta já existe.');
    return;
  }
  graph.edges.push({ from, to, weight: parsedWeight, directed: isDirected });
  graph.adjacency[from].push(to);
  if (!isDirected) {
    graph.adjacency[to].push(from);
  }
  updateSelectors();
  drawGraph();
}

function rebuildAdjacency() {
  graph.adjacency = {};
  graph.nodes.forEach((node) => {
    graph.adjacency[node.name] = [];
  });
  graph.edges.forEach((edge) => {
    const isDirected = edge.directed ?? graph.directed;
    graph.adjacency[edge.from].push(edge.to);
    if (!isDirected && !graph.adjacency[edge.to].includes(edge.from)) {
      graph.adjacency[edge.to].push(edge.from);
    }
  });
}

function transformGraphOrientation(newDirected) {
  if (graph.directed === newDirected) {
    graph.directed = newDirected;
    rebuildAdjacency();
    drawGraph();
    return;
  }

  if (!graph.directed && newDirected) {
    const transformed = [];
    graph.edges.forEach((edge) => {
      const baseEdge = {
        from: edge.from,
        to: edge.to,
        directed: true,
      };
      if (edge.weight !== undefined) {
        baseEdge.weight = edge.weight;
      }
      transformed.push(baseEdge);

      const reverseEdge = {
        from: edge.to,
        to: edge.from,
        directed: true,
      };
      if (edge.weight !== undefined) {
        reverseEdge.weight = edge.weight; 
      }
      transformed.push(reverseEdge);
    });
    graph.edges = transformed;
  } else if (graph.directed && !newDirected) {
    const transformed = [];
    const edgeMap = new Map();

    graph.edges.forEach((edge) => {
      const key = edge.from < edge.to ? `${edge.from}|${edge.to}` : `${edge.to}|${edge.from}`;
      const existing = edgeMap.get(key);
      if (existing) {
        if (existing.weight === undefined && edge.weight !== undefined) {
          existing.weight = edge.weight;
        }
      } else {
        edgeMap.set(key, {
          from: edge.from,
          to: edge.to,
          directed: false,
          weight: edge.weight,
        });
      }
    });

    edgeMap.forEach((value) => transformed.push(value));
    graph.edges = transformed;
  }

  graph.directed = newDirected;
  rebuildAdjacency();
  drawGraph();
}

function transformGraphWeighting(weighted) {
  if (weighted) {
    graph.edges.forEach((edge) => {
      if (edge.weight === undefined) {
        edge.weight = 1;
      }
    });
  } else {
    graph.edges.forEach((edge) => {
      delete edge.weight;
    });
  }
  drawGraph();
}

function updateGraphType() {
  transformGraphOrientation(graphTypeSelect.value === 'directed');
}

function generateNodeLabel(index) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  return alphabet[index] || `N${index + 1}`;
}

function initializeGraphNodes(count) {
  graph.nodes = [];
  graph.adjacency = {};
  for (let i = 0; i < count; i += 1) {
    const name = generateNodeLabel(i);
    graph.nodes.push({ id: `node-${name}`, name, x: 0, y: 0 });
    graph.adjacency[name] = [];
  }
}

function setCircleLayout(radius = 280, centerX = 500, centerY = 350) {
  const count = graph.nodes.length;
  graph.nodes.forEach((node, index) => {
    const angle = (index / count) * Math.PI * 2;
    node.x = centerX + Math.cos(angle) * radius;
    node.y = centerY + Math.sin(angle) * radius;
  });
}

function setTreeLayout() {
  const spacingX = 160;
  const spacingY = 120;
  graph.nodes.forEach((node, index) => {
    const depth = Math.floor(Math.log2(index + 1));
    const levelIndex = index - (2 ** depth - 1);
    const nodesInLevel = 2 ** depth;
    const xOffset = (levelIndex - (nodesInLevel - 1) / 2) * spacingX;
    node.x = 500 + xOffset;
    node.y = 80 + depth * spacingY;
  });
}

function setStarLayout() {
  const center = { x: 500, y: 350 };
  const radius = 220;
  graph.nodes.forEach((node, index) => {
    if (index === 0) {
      node.x = center.x;
      node.y = center.y;
      return;
    }
    const angle = ((index - 1) / (graph.nodes.length - 1)) * Math.PI * 2;
    node.x = center.x + Math.cos(angle) * radius;
    node.y = center.y + Math.sin(angle) * radius;
  });
}

function setBipartiteLayout() {
  const leftSize = Math.floor(graph.nodes.length / 2);
  const rightSize = graph.nodes.length - leftSize;
  const leftX = 250;
  const rightX = 750;
  const leftSpacing = 500 / Math.max(leftSize - 1, 1);
  const rightSpacing = 500 / Math.max(rightSize - 1, 1);
  graph.nodes.forEach((node, index) => {
    if (index < leftSize) {
      node.x = leftX;
      node.y = 120 + index * leftSpacing;
    } else {
      node.x = rightX;
      node.y = 120 + (index - leftSize) * rightSpacing;
    }
  });
}

function addGraphEdge(from, to, weight = undefined, directed = graph.directed) {
  if (!graph.adjacency[from] || !graph.adjacency[to]) return;
  graph.edges.push({ from, to, weight, directed });
  graph.adjacency[from].push(to);
  if (!directed) {
    graph.adjacency[to].push(from);
  }
}

function generateTree(size) {
  initializeGraphNodes(size);
  for (let i = 1; i < size; i += 1) {
    const parent = graph.nodes[Math.floor((i - 1) / 2)].name;
    const current = graph.nodes[i].name;
    addGraphEdge(parent, current, undefined, graph.directed);
  }
  setTreeLayout();
}

function generateCompleteGraph(size) {
  initializeGraphNodes(size);
  for (let i = 0; i < size; i += 1) {
    for (let j = i + 1; j < size; j += 1) {
      const from = graph.nodes[i].name;
      const to = graph.nodes[j].name;
      addGraphEdge(from, to, undefined, graph.directed);
      if (graph.directed) {
        addGraphEdge(to, from, undefined, graph.directed);
      }
    }
  }
  setCircleLayout();
}

function generateMultigraph(size) {
  initializeGraphNodes(size);
  setCircleLayout(200);
  if (size >= 2) {
    addGraphEdge(graph.nodes[0].name, graph.nodes[1].name, 1, graph.directed);
    addGraphEdge(graph.nodes[0].name, graph.nodes[1].name, 2, graph.directed);
  }
  if (size >= 3) {
    addGraphEdge(graph.nodes[1].name, graph.nodes[2].name, 3, graph.directed);
    addGraphEdge(graph.nodes[0].name, graph.nodes[2].name, 4, graph.directed);
  }
  for (let i = 3; i < size; i += 1) {
    addGraphEdge(graph.nodes[0].name, graph.nodes[i].name, undefined, graph.directed);
  }
}

function generateCycleGraph(size) {
  initializeGraphNodes(size);
  setCircleLayout(260);
  for (let i = 0; i < size; i += 1) {
    const from = graph.nodes[i].name;
    const to = graph.nodes[(i + 1) % size].name;
    addGraphEdge(from, to, undefined, graph.directed);
  }
}

function generateStarGraph(size) {
  initializeGraphNodes(size);
  setStarLayout();
  const center = graph.nodes[0].name;
  for (let i = 1; i < size; i += 1) {
    addGraphEdge(center, graph.nodes[i].name, undefined, graph.directed);
  }
}

function generateBipartiteGraph(size) {
  initializeGraphNodes(size);
  setBipartiteLayout();
  const leftSize = Math.floor(size / 2);
  for (let i = 0; i < leftSize; i += 1) {
    for (let j = leftSize; j < size; j += 1) {
      addGraphEdge(graph.nodes[i].name, graph.nodes[j].name, undefined, graph.directed);
    }
  }
}

function generateSpecialGraph() {
  const type = specialGraphTypeSelect.value;
  const size = Number(specialGraphSizeInput.value);
  if (!size || size < 2 || size > 26) {
    alert('Informe um tamanho entre 2 e 26.');
    return;
  }
  clearGraph();
  graph.directed = graphTypeSelect.value === 'directed';
  switch (type) {
    case 'tree':
      generateTree(size);
      break;
    case 'complete':
      generateCompleteGraph(size);
      break;
    case 'multigraph':
      generateMultigraph(size);
      break;
    case 'cycle':
      generateCycleGraph(size);
      break;
    case 'star':
      generateStarGraph(size);
      break;
    case 'bipartite':
      generateBipartiteGraph(size);
      break;
    default:
      break;
  }
  if (weightedGraphCheckbox.checked) {
    transformGraphWeighting(true);
  }
  updateSelectors();
  drawGraph();
}

function getGraphInfo() {
  const nodeCount = graph.nodes.length;
  const edgeCount = graph.edges.length;
  const directed = graph.edges.some((edge) => edge.directed) || graph.directed;
  const weighted = graph.edges.some((edge) => edge.weight !== undefined);
  const connected = isGraphConnected();
  const bipartite = isGraphBipartite();
  const graphType = getGraphTypeLabel();

  return {
    nodeCount,
    edgeCount,
    directed: directed ? 'Sim' : 'Não',
    weighted: weighted ? 'Sim' : 'Não',
    bipartite: bipartite ? 'Sim' : 'Não',
    connected: connected ? 'Sim' : 'Não',
    graphType,
  };
}

function getAdjacencyList() {
  const list = {};
  graph.nodes.forEach((node) => {
    list[node.name] = [];
  });

  graph.edges.forEach((edge) => {
    const weightText = edge.weight !== undefined ? ` (${edge.weight})` : '';
    list[edge.from].push(`${edge.to}${weightText}`);
    if (!edge.directed) {
      list[edge.to].push(`${edge.from}${weightText}`);
    }
  });

  return list;
}

function getAdjacencyMatrix() {
  const labels = graph.nodes.map((node) => node.name);
  const matrix = labels.map(() => labels.map(() => 0));

  graph.edges.forEach((edge) => {
    const i = labels.indexOf(edge.from);
    const j = labels.indexOf(edge.to);
    if (i === -1 || j === -1) return;
    const value = edge.weight !== undefined ? edge.weight : 1;
    matrix[i][j] += value;
    if (!edge.directed) {
      matrix[j][i] += value;
    }
  });

  return { labels, matrix };
}

function renderGraphRepresentation(type = 'list') {
  const container = document.getElementById('graphRepresentation');
  if (!container) return;

  if (type === 'matrix') {
    const { labels, matrix } = getAdjacencyMatrix();
    let html = '<div class="representation-title">Matriz de Adjacência</div>';
    html += '<div class="adjacency-matrix"><table><thead><tr><th></th>';
    labels.forEach((label) => {
      html += `<th>${label}</th>`;
    });
    html += '</tr></thead><tbody>';
    matrix.forEach((row, rowIndex) => {
      html += `<tr><th>${labels[rowIndex]}</th>`;
      row.forEach((value) => {
        html += `<td>${value}</td>`;
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    container.innerHTML = html;
    return;
  }

  const adjacencyList = getAdjacencyList();
  let html = '<div class="representation-title">Lista de Adjacência</div>';
  html += '<div class="adjacency-list">';
  Object.entries(adjacencyList).forEach(([node, neighbors]) => {
    const neighborText = neighbors.length > 0 ? neighbors.join(', ') : '∅';
    html += `<p><strong>${node}:</strong> ${neighborText}</p>`;
  });
  html += '</div>';
  container.innerHTML = html;
}

function showGraphInfo() {
  const info = getGraphInfo();
  graphInfoContent.innerHTML =
    `<p><strong>Nós:</strong> ${info.nodeCount}</p>` +
    `<p><strong>Arestas:</strong> ${info.edgeCount}</p>` +
    `<p><strong>Orientado:</strong> ${info.directed}</p>` +
    `<p><strong>Ponderado:</strong> ${info.weighted}</p>` +
    `<p><strong>Bipartido:</strong> ${info.bipartite}</p>` +
    `<p><strong>Conexo:</strong> ${info.connected}</p>` +
    `<p><strong>Tipo:</strong> ${info.graphType}</p>` +
    `<div class="representation-selector">
       <label><input type="radio" name="graphRepresentation" value="list" checked /> Lista de Adjacência</label>
       <label><input type="radio" name="graphRepresentation" value="matrix" /> Matriz de Adjacência</label>
     </div>` +
    `<div id="graphRepresentation"></div>`;
  renderGraphRepresentation('list');
}

function getUndirectedAdjacency() {
  const adjacency = {};
  graph.nodes.forEach((node) => {
    adjacency[node.name] = new Set();
  });
  graph.edges.forEach((edge) => {
    const from = edge.from;
    const to = edge.to;
    if (!adjacency[from] || !adjacency[to]) return;
    adjacency[from].add(to);
    adjacency[to].add(from);
  });
  return adjacency;
}

function isGraphConnected() {
  if (graph.nodes.length === 0) return false;
  const adj = getUndirectedAdjacency();
  const start = graph.nodes[0].name;
  const visited = new Set([start]);
  const queue = [start];

  while (queue.length > 0) {
    const node = queue.shift();
    adj[node].forEach((neighbor) => {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        queue.push(neighbor);
      }
    });
  }

  return visited.size === graph.nodes.length;
}

function isGraphBipartite() {
  const adj = getUndirectedAdjacency();
  const color = {};

  for (const node of graph.nodes) {
    const name = node.name;
    if (color[name] !== undefined) continue;
    const queue = [name];
    color[name] = 0;

    while (queue.length > 0) {
      const current = queue.shift();
      adj[current].forEach((neighbor) => {
        if (color[neighbor] === undefined) {
          color[neighbor] = 1 - color[current];
          queue.push(neighbor);
        } else if (color[neighbor] === color[current]) {
          return false;
        }
      });
    }
  }

  return true;
}

function getGraphTypeLabel() {
  const n = graph.nodes.length;
  const m = graph.edges.length;
  const hasLoop = graph.edges.some((edge) => edge.from === edge.to);
  const pairCounts = {};

  graph.edges.forEach((edge) => {
    const key = edge.from < edge.to ? `${edge.from}-${edge.to}` : `${edge.to}-${edge.from}`;
    pairCounts[key] = (pairCounts[key] || 0) + 1;
  });

  const hasParallel = Object.values(pairCounts).some((count) => count > 1);
  const isSimple = !hasLoop && !hasParallel;
  const complete = isCompleteGraph();
  const tree = isSimple && isGraphConnected() && m === Math.max(0, n - 1);

  if (!isSimple) return 'Multigrafo';
  if (tree) return 'Árvore';
  if (complete) return 'Completo';
  return 'Simples';
}

function isCompleteGraph() {
  const n = graph.nodes.length;
  if (n <= 1) return true;
  const adjacency = getUndirectedAdjacency();
  for (let i = 0; i < graph.nodes.length; i += 1) {
    for (let j = i + 1; j < graph.nodes.length; j += 1) {
      const a = graph.nodes[i].name;
      const b = graph.nodes[j].name;
      if (!adjacency[a].has(b)) {
        return false;
      }
    }
  }
  return true;
}

function clearGraph() {
  graph.nodes = [];
  graph.edges = [];
  graph.adjacency = {};
  algorithmState = null;
  currentStepIndex = 0;
  updateSelectors();
  drawGraph();
  clearDijkstraResult();
  writeOutput('Grafo limpo.');
}

function serializeGraphToText() {
  const header = ['# Grafo exportado pelo Visualizador de Grafos'];
  header.push(`directed: ${graph.directed}`);
  header.push(`weighted: ${graph.edges.some((edge) => edge.weight !== undefined)}`);
  header.push('nodes:');
  const nodeLines = graph.nodes.map((node) => `${node.name} ${node.x} ${node.y}`);
  header.push(...nodeLines);
  header.push('edges:');
  const edgeLines = graph.edges.map((edge) => {
    const weightText = edge.weight !== undefined ? edge.weight : '-';
    const directedText = Boolean(edge.directed).toString();
    return `${edge.from} ${edge.to} ${weightText} ${directedText}`;
  });
  header.push(...edgeLines);
  return header.join('\n');
}

function downloadGraphText(filename = 'grafo.txt') {
  const content = serializeGraphToText();
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function exportGraph() {
  if (graph.nodes.length === 0) {
    alert('Adicione ao menos um nó antes de exportar o grafo.');
    return;
  }
  downloadGraphText('grafo.txt');
}

function parseGraphText(text) {
  const lines = text.split(/\r?\n/).map((line) => line.trim());
  const data = { directed: false, weighted: false, nodes: [], edges: [] };
  let mode = null;

  lines.forEach((line) => {
    if (!line || line.startsWith('#')) return;
    if (/^directed:/i.test(line)) {
      data.directed = line.split(':')[1].trim().toLowerCase() === 'true';
      return;
    }
    if (/^weighted:/i.test(line)) {
      data.weighted = line.split(':')[1].trim().toLowerCase() === 'true';
      return;
    }
    if (/^nodes:/i.test(line)) {
      mode = 'nodes';
      return;
    }
    if (/^edges:/i.test(line)) {
      mode = 'edges';
      return;
    }
    if (mode === 'nodes') {
      const parts = line.split(/\s+/);
      if (parts.length < 3) {
        throw new Error('Formato de nó inválido. Cada linha deve ser: NOME X Y');
      }
      const name = parts[0];
      const x = Number(parts[1]);
      const y = Number(parts[2]);
      if (!name || Number.isNaN(x) || Number.isNaN(y)) {
        throw new Error('Dados de nó inválidos. Verifique o nome e as coordenadas.');
      }
      data.nodes.push({ name, x, y });
      return;
    }
    if (mode === 'edges') {
      const parts = line.split(/\s+/);
      if (parts.length !== 4) {
        throw new Error('Formato de aresta inválido. Cada linha deve ser: FROM TO PESO DIRECIONADO');
      }
      const from = parts[0];
      const to = parts[1];
      const weightText = parts[2];
      const directedText = parts[3].toLowerCase();
      const weight = weightText === '-' ? undefined : Number(weightText);
      if (weightText !== '-' && Number.isNaN(weight)) {
        throw new Error('Peso de aresta inválido. Use um número ou - para sem peso.');
      }
      if (directedText !== 'true' && directedText !== 'false') {
        throw new Error('Direção de aresta inválida. Use true ou false.');
      }
      data.edges.push({ from, to, weight, directed: directedText === 'true' });
      return;
    }
  });

  if (data.nodes.length === 0) {
    throw new Error('Nenhum nó encontrado no arquivo.');
  }
  return data;
}

function loadGraphFromText(text) {
  const parsed = parseGraphText(text);
  graph.nodes = parsed.nodes.map((node) => ({ id: `node-${node.name}`, name: node.name, x: node.x, y: node.y }));
  graph.edges = parsed.edges.map((edge) => ({ ...edge }));
  graph.directed = parsed.directed;
  rebuildAdjacency();
  graphTypeSelect.value = graph.directed ? 'directed' : 'undirected';
  weightedGraphCheckbox.checked = parsed.weighted;
  updateSelectors();
  drawGraph();
  writeOutput(`Grafo importado com ${graph.nodes.length} nós e ${graph.edges.length} arestas.`);
}

function importGraphFromFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      loadGraphFromText(reader.result);
    } catch (error) {
      alert(`Erro ao importar grafo: ${error.message}`);
    }
  };
  reader.onerror = () => {
    alert('Não foi possível ler o arquivo selecionado.');
  };
  reader.readAsText(file, 'UTF-8');
}

function updateSelectors() {
  const selects = [edgeFromSelect, edgeToSelect, startNodeSelect];
  selects.forEach((select) => {
    select.innerHTML = '<option value="">Selecione</option>';
  });
  graph.nodes.forEach((node) => {
    const option = document.createElement('option');
    option.value = node.name;
    option.textContent = node.name;
    selects.forEach((select) => select.appendChild(option.cloneNode(true)));
  });
  nodeCountLabel.textContent = graph.nodes.length;
  edgeCountLabel.textContent = graph.edges.length;
}

function createMarker() {
  const existing = document.getElementById('arrow');
  if (existing) return;
  const marker = document.createElementNS(svgNS, 'marker');
  marker.setAttribute('id', 'arrow');
  marker.setAttribute('markerWidth', '8');
  marker.setAttribute('markerHeight', '8');
  marker.setAttribute('refX', '18');
  marker.setAttribute('refY', '3');
  marker.setAttribute('orient', 'auto');
  marker.setAttribute('markerUnits', 'strokeWidth');
  const path = document.createElementNS(svgNS, 'path');
  path.setAttribute('d', 'M0,0 L6,3 L0,6 Z');
  path.setAttribute('fill', '#94a3b8');
  marker.appendChild(path);
  const defs = document.createElementNS(svgNS, 'defs');
  defs.appendChild(marker);
  graphCanvas.appendChild(defs);
}

function drawGraph() {
  graphCanvas.innerHTML = '';
  createMarker();
  svgElements = { nodes: {}, edges: {} };
  const edgeGroups = graph.edges.reduce((groups, edge, idx) => {
    const key = edge.from < edge.to ? `${edge.from}|${edge.to}` : `${edge.to}|${edge.from}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push({ edge, index: idx });
    return groups;
  }, {});

  graph.edges.forEach((edge, index) => {
    const fromNode = graph.nodes.find((node) => node.name === edge.from);
    const toNode = graph.nodes.find((node) => node.name === edge.to);
    if (!fromNode || !toNode) return;
    const group = document.createElementNS(svgNS, 'g');
    group.classList.add('edge');
    const line = document.createElementNS(svgNS, 'path');
    const dx = toNode.x - fromNode.x;
    const dy = toNode.y - fromNode.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const offset = 18;
    const startX = fromNode.x + (dx / distance) * offset;
    const startY = fromNode.y + (dy / distance) * offset;
    const endX = toNode.x - (dx / distance) * offset;
    const endY = toNode.y - (dy / distance) * offset;
    const edgeDirected = edge.directed ?? graph.directed;
    const key = edge.from < edge.to ? `${edge.from}|${edge.to}` : `${edge.to}|${edge.from}`;
    const groupedEdges = edgeGroups[key] || [];
    const sameDirectionEdges = groupedEdges.filter(
      (item) => item.edge.from === edge.from && item.edge.to === edge.to
    );
    const directionIndex = sameDirectionEdges.findIndex((item) => item.index === index);
    const isParallel = groupedEdges.length > 1;
    const curveSign = edge.from < edge.to ? 1 : -1;
    const baseCurveOffset = 46;
    const curveOffset = baseCurveOffset + directionIndex * 20;

    let pathData;
    if (isParallel) {
      const midX = (startX + endX) / 2;
      const midY = (startY + endY) / 2;
      const perpX = -dy / distance;
      const perpY = dx / distance;
      const controlX = midX + perpX * curveOffset * curveSign;
      const controlY = midY + perpY * curveOffset * curveSign;
      pathData = `M ${startX} ${startY} Q ${controlX} ${controlY} ${endX} ${endY}`;
    } else {
      pathData = `M ${startX} ${startY} L ${endX} ${endY}`;
    }

    line.setAttribute('d', pathData);
    line.setAttribute('fill', 'none');
    line.setAttribute('stroke-linecap', 'round');
    if (edgeDirected) {
      line.setAttribute('marker-end', 'url(#arrow)');
    }
    group.appendChild(line);

    if (edge.weight !== undefined) {
      const weightText = document.createElementNS(svgNS, 'text');
      weightText.classList.add('edge-weight');
      if (isParallel) {
        const midX = (startX + endX) / 2;
        const midY = (startY + endY) / 2;
        const perpX = -dy / distance;
        const perpY = dx / distance;
        const labelOffset = curveOffset + 18;
        weightText.setAttribute('x', midX + perpX * labelOffset * curveSign);
        weightText.setAttribute('y', midY + perpY * labelOffset * curveSign - 14);
      } else {
        weightText.setAttribute('x', (startX + endX) / 2);
        weightText.setAttribute('y', (startY + endY) / 2 - 10);
      }
      weightText.setAttribute('text-anchor', 'middle');
      weightText.setAttribute('dominant-baseline', 'central');
      weightText.textContent = edge.weight;
      group.appendChild(weightText);
      weightText.addEventListener('dblclick', (event) => {
        event.stopPropagation();
        onEdgeDoubleClick(edge);
      });
    }

    group.addEventListener('dblclick', (event) => {
      event.stopPropagation();
      onEdgeDoubleClick(edge);
    });

    group.dataset.edgeIndex = index;
    group.addEventListener('click', (event) => {
      event.stopPropagation();
      selectEdge(index);
    });
    graphCanvas.appendChild(group);
    svgElements.edges[index] = group;
  });

  graph.nodes.forEach((node) => {
    const group = document.createElementNS(svgNS, 'g');
    group.classList.add('node');
    group.dataset.name = node.name;
    group.setAttribute('transform', `translate(${node.x}, ${node.y})`);
    const circle = document.createElementNS(svgNS, 'circle');
    circle.setAttribute('r', '14');
    circle.setAttribute('cx', '0');
    circle.setAttribute('cy', '0');
    const text = document.createElementNS(svgNS, 'text');
    text.textContent = node.name;
    group.appendChild(circle);
    group.appendChild(text);
    group.addEventListener('pointerdown', onNodePointerDown);
    group.addEventListener('click', (event) => {
      if (!event.altKey) {
        event.stopPropagation();
        selectNode(node.name);
      }
    });
    circle.addEventListener('dblclick', (event) => {
      event.stopPropagation();
      onNodeDoubleClick(node);
    });
    text.addEventListener('dblclick', (event) => {
      event.stopPropagation();
      onNodeDoubleClick(node);
    });
    graphCanvas.appendChild(group);
    svgElements.nodes[node.name] = group;
  });

  updateHighlights();
  updateGraphViewBox();
}

function setZoom(level) {
  const normalized = Math.max(minZoomLevel, Math.min(maxZoomLevel, level));
  const width = svgWidth / normalized;
  const height = svgHeight / normalized;
  const centerX = viewBoxX + (svgWidth / zoomLevel) / 2;
  const centerY = viewBoxY + (svgHeight / zoomLevel) / 2;
  zoomLevel = normalized;

  const minX = Math.min(0, svgWidth - width);
  const maxX = Math.max(0, svgWidth - width);
  const minY = Math.min(0, svgHeight - height);
  const maxY = Math.max(0, svgHeight - height);

  viewBoxX = Math.min(Math.max(centerX - width / 2, minX), maxX);
  viewBoxY = Math.min(Math.max(centerY - height / 2, minY), maxY);
  updateGraphViewBox();
}

function zoomIn() {
  setZoom(zoomLevel + zoomStep);
}

function zoomOut() {
  setZoom(zoomLevel - zoomStep);
}

function panCamera(dx, dy) {
  const width = svgWidth / zoomLevel;
  const height = svgHeight / zoomLevel;
  const minX = Math.min(0, svgWidth - width);
  const maxX = Math.max(0, svgWidth - width);
  const minY = Math.min(0, svgHeight - height);
  const maxY = Math.max(0, svgHeight - height);

  viewBoxX = Math.min(Math.max(viewBoxX + dx, minX), maxX);
  viewBoxY = Math.min(Math.max(viewBoxY + dy, minY), maxY);
  updateGraphViewBox();
}

function updateGraphViewBox() {
  const width = svgWidth / zoomLevel;
  const height = svgHeight / zoomLevel;
  const minX = Math.min(0, svgWidth - width);
  const maxX = Math.max(0, svgWidth - width);
  const minY = Math.min(0, svgHeight - height);
  const maxY = Math.max(0, svgHeight - height);
  const x = Math.min(Math.max(viewBoxX, minX), maxX);
  const y = Math.min(Math.max(viewBoxY, minY), maxY);
  viewBoxX = x;
  viewBoxY = y;
  graphCanvas.setAttribute('viewBox', `${x} ${y} ${width} ${height}`);
}

function onGraphZoom(event) {
  event.preventDefault();
  setZoom(zoomLevel * (event.deltaY > 0 ? 0.86 : 1.14));
}

function selectNode(nodeName) {
  selectedNode = nodeName;
  selectedEdge = null;
  updateHighlights();
}

function selectEdge(index) {
  selectedEdge = index;
  selectedNode = null;
  updateHighlights();
}

function clearSelection() {
  selectedNode = null;
  selectedEdge = null;
  updateHighlights();
}

function getSelectedInfoText() {
  if (selectedNode) {
    return `Nó selecionado: ${selectedNode}`;
  }
  if (selectedEdge !== null) {
    const edge = graph.edges[selectedEdge];
    if (edge) {
      const weightText = edge.weight !== undefined ? ` (peso ${edge.weight})` : '';
      const directedText = edge.directed ? 'Orientada' : 'Não orientada';
      return `Aresta selecionada: ${edge.from} → ${edge.to}${weightText} — ${directedText}`;
    }
  }
  return 'Nenhum elemento selecionado';
}

function updateSelectedInfo() {
  const selectedInfo = document.getElementById('selectedInfo');
  if (!selectedInfo) return;
  selectedInfo.innerHTML = `<p><strong>Selecionado:</strong> ${getSelectedInfoText()}</p>`;
}

function cycleSelection(forward = true) {
  const nodeCount = graph.nodes.length;
  const edgeCount = graph.edges.length;
  if (nodeCount === 0 && edgeCount === 0) return;

  if (selectedNode) {
    if (edgeCount > 0) {
      selectEdge(0);
      return;
    }
    const currentIndex = graph.nodes.findIndex((node) => node.name === selectedNode);
    const nextIndex = forward
      ? (currentIndex + 1) % nodeCount
      : (currentIndex - 1 + nodeCount) % nodeCount;
    selectNode(graph.nodes[nextIndex].name);
    return;
  }

  if (selectedEdge !== null) {
    if (nodeCount > 0) {
      selectNode(graph.nodes[0].name);
      return;
    }
    const nextIndex = forward
      ? (selectedEdge + 1) % edgeCount
      : (selectedEdge - 1 + edgeCount) % edgeCount;
    selectEdge(nextIndex);
    return;
  }

  if (nodeCount > 0) {
    selectNode(graph.nodes[0].name);
    return;
  }

  selectEdge(0);
}

function deleteSelected() {
  if (selectedNode) {
    deleteNode(selectedNode);
  } else if (selectedEdge !== null) {
    deleteEdge(selectedEdge);
  }
}

function deleteNode(nodeName) {
  graph.nodes = graph.nodes.filter((node) => node.name !== nodeName);
  graph.edges = graph.edges.filter((edge) => edge.from !== nodeName && edge.to !== nodeName);
  if (edgeSourceNode === nodeName) {
    edgeSourceNode = null;
  }
  selectedNode = null;
  selectedEdge = null;
  rebuildAdjacency();
  updateSelectors();
  drawGraph();
}

function deleteEdge(index) {
  if (index < 0 || index >= graph.edges.length) return;
  graph.edges.splice(index, 1);
  selectedEdge = null;
  rebuildAdjacency();
  updateSelectors();
  drawGraph();
}

function onNodePointerDown(event) {
  event.stopPropagation();
  const nodeName = event.currentTarget.dataset.name;
  if (event.altKey) {
    event.preventDefault();
    handleAltNodeClick(nodeName);
    return;
  }
  if (event.detail > 1) return;
  dragTarget = graph.nodes.find((node) => node.name === nodeName);
  if (!dragTarget) return;
  isDragging = true;
  const point = getPoint(event);
  dragOffset.x = dragTarget.x - point.x;
  dragOffset.y = dragTarget.y - point.y;
}

function onCanvasPointerDown(event) {
  const clickedNodeOrEdge = event.target.closest && event.target.closest('g.node, g.edge');
  if (clickedNodeOrEdge) return;
  if (event.target !== graphCanvas) return;
  event.preventDefault();
  isPanning = true;
  panStart = { x: event.clientX, y: event.clientY };
  if (event.pointerId !== undefined && graphCanvas.setPointerCapture) {
    graphCanvas.setPointerCapture(event.pointerId);
  }
}

function onPointerMove(event) {
  if (isPanning) {
    const rect = graphCanvas.getBoundingClientRect();
    const viewWidth = svgWidth / zoomLevel;
    const viewHeight = svgHeight / zoomLevel;
    const deltaX = ((panStart.x - event.clientX) * viewWidth) / rect.width;
    const deltaY = ((panStart.y - event.clientY) * viewHeight) / rect.height;
    panCamera(deltaX, deltaY);
    panStart = { x: event.clientX, y: event.clientY };
    return;
  }
  if (!isDragging || !dragTarget) return;
  const point = getPoint(event);
  dragTarget.x = point.x + dragOffset.x;
  dragTarget.y = point.y + dragOffset.y;
  drawGraph();
}

function onPointerUp(event) {
  if (event && event.pointerId !== undefined && graphCanvas.hasPointerCapture && graphCanvas.hasPointerCapture(event.pointerId)) {
    graphCanvas.releasePointerCapture(event.pointerId);
  }
  isDragging = false;
  isPanning = false;
  dragTarget = null;
}

function getPoint(event) {
  const rect = graphCanvas.getBoundingClientRect();
  const x = ((event.clientX - rect.left) / rect.width) * svgWidth;
  const y = ((event.clientY - rect.top) / rect.height) * svgHeight;
  return { x, y };
}

function runSearch(type) {
  const start = startNodeSelect.value;
  if (!start) {
    alert('Selecione um nó inicial.');
    return;
  }
  if (graph.nodes.length === 0) {
    alert('Adicione ao menos um nó.');
    return;
  }

  algorithmState = {
    type,
    source: start,
    prev: {},
    visited: new Set(),
    queue: [],
    stack: [],
    steps: [],
    walkthrough: [],
    visitedOrder: [],
    completionNotified: false,
  };

  clearDijkstraResult();
  if (type === 'BFS') {
    bfsGenerateSteps(start);
  } else if (type === 'DFS') {
    dfsGenerateSteps(start);
  } else {
    dijkstraGenerateSteps(start);
  }
  currentStepIndex = 0;
  renderStep();
}

function getEdgeWeight(from, to) {
  const matchingEdges = graph.edges.filter((edge) => {
    if (edge.from === from && edge.to === to) return true;
    if (!edge.directed && edge.from === to && edge.to === from) return true;
    return false;
  });
  if (matchingEdges.length === 0) return 1;
  return Math.min(...matchingEdges.map((edge) => (edge.weight !== undefined ? edge.weight : 1)));
}

function bfsGenerateSteps(start) {
  const visited = new Set();
  const queue = [start];
  algorithmState.walkthrough.push(`Início BFS em ${start}`);
  visited.add(start);
  algorithmState.visitedOrder.push(start);
  algorithmState.steps.push(snapshot('Visitado', start, [...queue], [...visited]));

  while (queue.length > 0) {
    const node = queue.shift();
    algorithmState.steps.push(snapshot('Processando', node, [...queue], [...visited]));
    const neighbors = graph.adjacency[node] || [];
    neighbors.forEach((neighbor) => {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        algorithmState.visitedOrder.push(neighbor);
        queue.push(neighbor);
        algorithmState.steps.push(snapshot('Encontrado vizinho', neighbor, [...queue], [...visited], node));
      }
    });
  }
  algorithmState.steps.push(snapshot('Finalizado', null, [], [...visited], null));
}

function dfsGenerateSteps(start) {
  const visited = new Set();
  const stack = [start];
  algorithmState.steps.push(snapshot('Início DFS', start, [...stack], [...visited]));

  while (stack.length > 0) {
    const node = stack.pop();
    if (!visited.has(node)) {
      visited.add(node);
      algorithmState.visitedOrder.push(node);
      algorithmState.steps.push(snapshot('Visitado', node, [...stack], [...visited]));
      const neighbors = [...(graph.adjacency[node] || [])].reverse();
      neighbors.forEach((neighbor) => {
        if (!visited.has(neighbor)) {
          stack.push(neighbor);
          algorithmState.steps.push(snapshot('Empilhado', neighbor, [...stack], [...visited], node));
        }
      });
    }
  }
  algorithmState.steps.push(snapshot('Finalizado', null, [], [...visited]));
}

function dijkstraGenerateSteps(start) {
  const dist = {};
  const prev = {};
  const visited = new Set();
  const frontier = [];

  graph.nodes.forEach((node) => {
    dist[node.name] = Infinity;
    prev[node.name] = null;
  });
  dist[start] = 0;
  frontier.push({ node: start, dist: 0 });
  algorithmState.walkthrough.push(`Início Dijkstra em ${start}`);
  algorithmState.steps.push(
    snapshot(
      'Início Dijkstra',
      start,
      frontier.map((item) => `${item.node}(${item.dist})`),
      [...visited],
      null,
      { dist: { ...dist } }
    )
  );

  while (frontier.length > 0) {
    frontier.sort((a, b) => a.dist - b.dist);
    const currentItem = frontier.shift();
    const node = currentItem.node;
    if (visited.has(node)) {
      continue;
    }

    visited.add(node);
    algorithmState.visitedOrder.push(node);
    algorithmState.steps.push(
      snapshot(
        'Visitado',
        node,
        frontier.map((item) => `${item.node}(${item.dist})`),
        [...visited],
        null,
        { dist: { ...dist } }
      )
    );

    const neighbors = graph.adjacency[node] || [];
    neighbors.forEach((neighbor) => {
      if (visited.has(neighbor)) return;
      const weight = getEdgeWeight(node, neighbor);
      const candidate = dist[node] + weight;
      if (candidate < dist[neighbor]) {
        dist[neighbor] = candidate;
        prev[neighbor] = node;
        frontier.push({ node: neighbor, dist: candidate });
        algorithmState.steps.push(
          snapshot(
            'Atualizado distância',
            neighbor,
            frontier.map((item) => `${item.node}(${item.dist})`),
            [...visited],
            node,
            { dist: { ...dist } }
          )
        );
      }
    });
  }

  algorithmState.prev = { ...prev };
  algorithmState.steps.push(
    snapshot('Finalizado', null, [], [...visited], null, { dist: { ...dist } })
  );
}

function snapshot(action, current, queueOrStack, visited, from, extra = {}) {
  return { action, current, queueOrStack, visited, from, ...extra };

}

function renderStep() {
  if (!algorithmState) return;
  const step = algorithmState.steps[currentStepIndex];
  if (!step) return;
  const visited = new Set(step.visited || []);
  const current = step.current;
  updateHighlights(current, visited, step.from);

  const structureLabel = algorithmState.type === 'BFS' ? 'Fila' : algorithmState.type === 'DFS' ? 'Pilha' : 'Frente';
  const container = [];
  container.push(`Passo ${currentStepIndex + 1} de ${algorithmState.steps.length}`);
  container.push(`Algoritmo: ${algorithmState.type}`);
  container.push(`Ação: ${step.action}`);
  if (current) container.push(`Nó atual: ${current}`);
  if (step.from) container.push(`Vindo de: ${step.from}`);
  container.push(`${structureLabel}: ${step.queueOrStack.join(', ') || 'vazia'}`);
  if (step.dist) {
    const distEntries = Object.keys(step.dist)
      .sort()
      .map((node) => `${node}=${step.dist[node] === Infinity ? '∞' : step.dist[node]}`);
    container.push(`Distâncias: ${distEntries.join(', ')}`);
  }

  if (algorithmState.type === 'DIJKSTRA' && step.action === 'Finalizado') {
    const prev = algorithmState.prev || {};
    const source = algorithmState.source;
    const distMap = step.dist || {};
    const nodes = graph.nodes.map((node) => node.name).sort();
    container.push('Melhores caminhos:');
    nodes.forEach((nodeName) => {
      const path = [];
      let current = nodeName;
      while (current !== null && current !== undefined) {
        path.unshift(current);
        if (current === source) break;
        current = prev[current];
      }
      const cost = distMap[nodeName] === Infinity ? '∞' : distMap[nodeName];
      if (current !== source) {
        container.push(`  ${nodeName}: sem caminho`);
      } else {
        container.push(`  ${nodeName}: ${path.join(' → ')} (custo ${cost})`);
      }
    });
  }

  container.push(`Ordem de visita: ${algorithmState.visitedOrder.join(', ') || 'nenhum'}`);
  container.push(`Visitados: ${[...visited].join(', ') || 'nenhum'}`);
  writeOutput(container.join('\n'));
  if (!algorithmState.completionNotified && step.action === 'Finalizado') {
    algorithmState.completionNotified = true;
    if (algorithmState.type === 'DIJKSTRA') {
      const source = algorithmState.source;
      const prev = algorithmState.prev || {};
      const distMap = step.dist || {};
      const nodes = graph.nodes.map((node) => node.name).sort();
      const lines = [`Dijkstra concluído a partir de ${source}:`, '', 'Melhores caminhos finais e custos:'];
      nodes.forEach((nodeName) => {
        if (nodeName === source) {
          lines.push(`  ${source}: custo 0`);
          return;
        }
        const path = [];
        let current = nodeName;
        while (current !== null && current !== undefined) {
          path.unshift(current);
          if (current === source) break;
          current = prev[current];
        }
        if (current !== source) {
          lines.push(`  ${nodeName}: sem caminho`);
        } else {
          const cost = distMap[nodeName] === Infinity ? '∞' : distMap[nodeName];
          lines.push(`  ${path.join(' → ')} (custo ${cost})`);
        }
      });
      showDijkstraResult(lines);
    } else {
      const resultText = algorithmState.visitedOrder.length > 0 ? algorithmState.visitedOrder.join(' → ') : 'nenhum nó visitado';
      alert(`${algorithmState.type} concluído. Resultado: ${resultText}`);
    }
  }
}

function updateHighlights(current = null, visited = new Set(), from = null) {
  graph.nodes.forEach((node) => {
    const element = svgElements.nodes[node.name];
    if (!element) return;
    element.classList.toggle('active', node.name === current);
    element.classList.toggle('current', node.name === current);
    element.classList.toggle('visited', visited.has(node.name) && node.name !== current);
    element.classList.toggle('selected-edge', node.name === edgeSourceNode);
    element.classList.toggle('selected', node.name === selectedNode);
  });

  Object.entries(svgElements.edges).forEach(([key, edgeElement]) => {
    const edgeIndex = Number(key);
    const edge = graph.edges[edgeIndex];
    if (!edge) return;
    const isTraversed = from && from === edge.from && edge.to === current;
    edgeElement.classList.toggle('visited', visited.has(edge.from) && visited.has(edge.to));
    edgeElement.classList.toggle('active', isTraversed);
    edgeElement.classList.toggle('selected', edgeIndex === selectedEdge);
  });
  updateSelectedInfo();
}

function onNodeDoubleClick(node) {
  const newName = prompt('Editar nome do nó:', node.name);
  if (newName === null) return;
  const normalized = newName.trim().toUpperCase();
  if (!normalized || normalized === node.name) return;
  if (graph.nodes.some((item) => item.name === normalized)) {
    alert('Nome já existe.');
    return;
  }

  const oldName = node.name;
  node.name = normalized;
  node.id = `node-${normalized}`;

  graph.adjacency[normalized] = graph.adjacency[oldName];
  delete graph.adjacency[oldName];

  graph.nodes.forEach((item) => {
    graph.adjacency[item.name] = graph.adjacency[item.name].map((neighbor) =>
      neighbor === oldName ? normalized : neighbor
    );
  });

  graph.edges.forEach((edge) => {
    if (edge.from === oldName) edge.from = normalized;
    if (edge.to === oldName) edge.to = normalized;
  });

  if (edgeSourceNode === oldName) {
    edgeSourceNode = normalized;
  }

  updateSelectors();
  drawGraph();
}

function handleAltNodeClick(nodeName) {
  if (!edgeSourceNode) {
    edgeSourceNode = nodeName;
    writeOutput(`Nó de origem selecionado: ${nodeName}. Alt+clique em outro nó para criar a aresta.`);
    drawGraph();
    return;
  }

  if (edgeSourceNode === nodeName) {
    writeOutput('Selecione um nó diferente para criar a aresta.');
    return;
  }

  const directed = confirm('A aresta deve ser orientada? Clique em OK para Sim, Cancelar para Não.');
  const hasWeight = confirm('A aresta deve ter peso? Clique em OK para Sim, Cancelar para Não.');
  let weightInput = '';
  if (hasWeight) {
    weightInput = prompt('Informe o peso da aresta:', '1');
    if (weightInput === null) {
      edgeSourceNode = null;
      drawGraph();
      return;
    }
    weightInput = weightInput.trim();
  }

  addEdge(edgeSourceNode, nodeName, weightInput, directed);
  edgeSourceNode = null;
  drawGraph();
}

function onEdgeDoubleClick(edge) {
  const currentWeight = edge.weight !== undefined ? edge.weight : '';
  const newWeight = prompt(`Editar peso da aresta ${edge.from} → ${edge.to}: (deixe vazio para sem peso)`, currentWeight);
  if (newWeight === null) return;
  const trimmed = newWeight.trim();
  if (trimmed === '') {
    delete edge.weight;
    drawGraph();
    return;
  }
  const parsedWeight = Number(trimmed);
  if (Number.isNaN(parsedWeight)) {
    alert('Peso inválido.');
    return;
  }
  edge.weight = parsedWeight;
  drawGraph();
}

function writeOutput(text) {
  output.textContent = text;
}

function showDijkstraResult(lines) {
  if (!dijkstraResult || !dijkstraResultContent) return;
  dijkstraResultContent.textContent = lines.join('\n');
  dijkstraResult.classList.add('visible');
}

function clearDijkstraResult() {
  if (!dijkstraResult || !dijkstraResultContent) return;
  dijkstraResultContent.textContent = 'Execute Dijkstra para ver o melhor caminho e custo.';
  dijkstraResult.classList.remove('visible');
}

addNodeButton.addEventListener('click', () => {
  addNode(nodeNameInput.value.trim().toUpperCase());
  nodeNameInput.value = '';
});

nodeNameInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    addNode(nodeNameInput.value.trim().toUpperCase());
    nodeNameInput.value = '';
  }
});

edgeWeightInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    addEdge(edgeFromSelect.value, edgeToSelect.value, edgeWeightInput.value);
  }
});

addEdgeButton.addEventListener('click', () => {
  addEdge(edgeFromSelect.value, edgeToSelect.value, edgeWeightInput.value);
});

generateSpecialGraphButton.addEventListener('click', generateSpecialGraph);

zoomInButton.addEventListener('click', () => {
  zoomIn();
});

zoomOutButton.addEventListener('click', () => {
  zoomOut();
});

panUpButton.addEventListener('click', () => {
  panCamera(0, -90 / zoomLevel);
});

panLeftButton.addEventListener('click', () => {
  panCamera(-90 / zoomLevel, 0);
});

panRightButton.addEventListener('click', () => {
  panCamera(90 / zoomLevel, 0);
});

panDownButton.addEventListener('click', () => {
  panCamera(0, 90 / zoomLevel);
});

graphTypeSelect.addEventListener('change', updateGraphType);
weightedGraphCheckbox.addEventListener('change', () => transformGraphWeighting(weightedGraphCheckbox.checked));

graphInfoButton.addEventListener('click', () => {
  showGraphInfo();
  graphInfoModal.classList.add('open');
  graphInfoModal.setAttribute('aria-hidden', 'false');
});

graphInfoContent.addEventListener('change', (event) => {
  if (event.target.name === 'graphRepresentation') {
    renderGraphRepresentation(event.target.value);
  }
});

graphInfoClose.addEventListener('click', () => {
  graphInfoModal.classList.remove('open');
  graphInfoModal.setAttribute('aria-hidden', 'true');
});

graphInfoModal.addEventListener('click', (event) => {
  if (event.target === graphInfoModal) {
    graphInfoModal.classList.remove('open');
    graphInfoModal.setAttribute('aria-hidden', 'true');
  }
});

toggleEditPanelButton.addEventListener('click', () => {
  const collapsed = editPanel.classList.toggle('collapsed');
  toggleEditPanelButton.textContent = collapsed ? 'Editar grafo' : 'Fechar editor';
});

toggleStatusPanelButton.addEventListener('click', () => {
  const collapsed = statusPanel.classList.toggle('collapsed');
  toggleStatusPanelButton.textContent = collapsed ? '▶' : '▼';
  toggleStatusPanelButton.setAttribute('aria-expanded', String(!collapsed));
});

toggleExecutionPanelButton.addEventListener('click', () => {
  const collapsed = executionPanel.classList.toggle('collapsed');
  toggleExecutionPanelButton.textContent = collapsed ? '▶' : '▼';
  toggleExecutionPanelButton.setAttribute('aria-expanded', String(!collapsed));
});

window.addEventListener('keydown', (event) => {
  const key = event.key.toLowerCase();
  const tag = event.target.tagName.toLowerCase();
  const isFormElement = tag === 'input' || tag === 'textarea' || tag === 'select' || event.target.isContentEditable;
  if (isFormElement) return;

  if (key === 'delete' || key === 'backspace') {
    event.preventDefault();
    deleteSelected();
    return;
  }

  if (key === 's' && !event.ctrlKey && !event.altKey && !event.metaKey) {
    event.preventDefault();
    cycleSelection(!event.shiftKey);
    return;
  }

  if (key === 'n' && !event.ctrlKey && !event.altKey && !event.metaKey) {
    event.preventDefault();
    const newName = prompt('Digite o nome do novo nó:');
    if (newName === null) return;
    addNode(newName.trim().toUpperCase());
    return;
  }

  if (key === 'arrowleft' || key === 'arrowright' || key === 'arrowup' || key === 'arrowdown') {
    event.preventDefault();
    const panAmount = 90 / zoomLevel;
    if (key === 'arrowleft') panCamera(-panAmount, 0);
    if (key === 'arrowright') panCamera(panAmount, 0);
    if (key === 'arrowup') panCamera(0, -panAmount);
    if (key === 'arrowdown') panCamera(0, panAmount);
    return;
  }

  if (event.altKey && !event.ctrlKey && !event.metaKey) {
    if (key === 'n') {
      event.preventDefault();
      nodeNameInput.focus();
      return;
    }
    if (key === 'e') {
      event.preventDefault();
      addEdge(edgeFromSelect.value, edgeToSelect.value, edgeWeightInput.value, true);
      return;
    }
  }
});

runBFSButton.addEventListener('click', () => runSearch('BFS'));
runDFSButton.addEventListener('click', () => runSearch('DFS'));
runDijkstraButton.addEventListener('click', () => runSearch('DIJKSTRA'));
prevStepButton.addEventListener('click', () => {
  if (!algorithmState || currentStepIndex === 0) return;
  currentStepIndex -= 1;
  renderStep();
});
nextStepButton.addEventListener('click', () => {
  if (!algorithmState || currentStepIndex === algorithmState.steps.length - 1) return;
  currentStepIndex += 1;
  renderStep();
});
resetAlgoButton.addEventListener('click', () => {
  algorithmState = null;
  currentStepIndex = 0;
  updateHighlights();
  clearDijkstraResult();
  writeOutput('Busca reiniciada.');
});
clearGraphButton.addEventListener('click', clearGraph);
exportGraphButton.addEventListener('click', exportGraph);
importGraphButton.addEventListener('click', () => importGraphInput.click());
importGraphInput.addEventListener('change', (event) => {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  importGraphFromFile(file);
  importGraphInput.value = '';
});

graphCanvas.addEventListener('pointerdown', onCanvasPointerDown);
graphCanvas.addEventListener('pointermove', onPointerMove);
graphCanvas.addEventListener('pointerup', onPointerUp);
graphCanvas.addEventListener('pointercancel', onPointerUp);
graphCanvas.addEventListener('pointerleave', onPointerUp);
graphCanvas.addEventListener('click', clearSelection);
graphCanvas.addEventListener('wheel', onGraphZoom, { passive: false });

drawGraph();
updateSelectors();
